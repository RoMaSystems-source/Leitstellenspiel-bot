# 📋 CHANGELOG

## Version 3.0.0 (2026-01-06) 🎉

### 🎉 MAJOR UPDATE - Version 3.0.0

Dies ist ein großes Update mit vielen neuen Features und Verbesserungen!

### ✨ Neue Features

#### 📊 Fortschrittsbalken für Updates
- **Download-Fortschritt in Echtzeit**: Beim Auto-Update wird jetzt der Download-Fortschritt angezeigt
- **Prozentanzeige**: Visueller Fortschrittsbalken mit Prozentangabe
- **Dateigröße-Anzeige**: Zeigt heruntergeladene und Gesamt-Dateigröße
- **Beispiel**: `📊 Download: [████████████░░░░░░░░] 60% (12.5 MB / 20.8 MB)`

#### 🌓 Dark/Light Mode Toggle
- **Theme-Wechsel**: Toggle-Button im Header (rechts oben) zum Wechseln zwischen Dark und Light Mode
- **Automatische Speicherung**: Die Theme-Einstellung wird automatisch gespeichert
- **Benachrichtigungen**: Zeigt "🌙 Dark Mode aktiviert" oder "☀️ Light Mode aktiviert"
- **Persistenz**: Theme-Einstellung bleibt nach Neustart erhalten

#### 📈 Erweiterte Statistiken
Neue Statistik-Karten im Dashboard:
- **Erfolgsrate**: Zeigt die Erfolgsquote in Prozent (erfolgreiche vs. fehlgeschlagene Einsätze)
- **Ø Zeit/Einsatz**: Durchschnittliche Bearbeitungszeit pro Einsatz in Sekunden
- **Einsätze/Stunde**: Berechnet wie viele Einsätze pro Stunde bearbeitet werden
- **Echtzeit-Updates**: Alle Statistiken werden live aktualisiert

### 🔧 Verbesserungen
- Bessere Fehlerbehandlung beim Download
- Optimierte Performance bei Statistik-Berechnungen
- Verbesserte UI-Responsivität

### 🐛 Bugfixes
- Import-Fehler behoben (os-Modul wird jetzt korrekt importiert)
- Auto-Update funktioniert jetzt ohne UnboundLocalError
- Version wird dynamisch aus version.txt gelesen
- Bot beendet sich korrekt vor Update

### 🔴 Bestehende Features
- Rote Einsätze haben Priorität beim Abarbeiten
- Automatische Fahrzeugauswahl basierend auf Einsatzanforderungen
- Live-Logs im GUI
- Session-Management mit automatischem Re-Login
- Intelligente Nachalarmierungs-Erkennung

---

## Version 2.8.0 (2026-01-06)

### 🔧 Kritische Fixes
- Import-Fehler behoben (os-Modul)
- Auto-Update funktioniert vollständig
- Bot beendet sich korrekt vor Update

### ✨ Neue Features
- Version wird dynamisch aus version.txt gelesen
- UI zeigt korrekte Version
- Rote Einsätze haben Priorität

---

## Version 2.6.0 (2026-01-05)

### ✨ Neue Features
- Professionelles GUI mit customtkinter
- Dashboard mit Live-Statistiken
- Live-Logs im GUI
- Auto-Update-Funktion

### 🔧 Verbesserungen
- Bessere Fehlerbehandlung
- Optimierte Performance
- Verbesserte Benutzeroberfläche

---

## Version 2.0.0 (2026-01-04)

### ✨ Neue Features
- Selenium-basierte Browser-Automation
- Intelligente Fahrzeugauswahl
- Session-Management
- Automatische Nachalarmierung

---

## Version 1.0.0 (2026-01-03)

### 🎉 Erste Version
- Grundlegende Bot-Funktionalität
- Login-System
- Einsatz-Abarbeitung
- Fahrzeug-Alarmierung

